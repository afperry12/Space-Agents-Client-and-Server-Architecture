// using System;
// using UnityEngine;
//
// public class CameraFollow : MonoBehaviour
// {
//
//     public Transform target;
//     
//     public float smooth = 1f;
//     public Vector3 offset;
//
//     private void FixedUpdate()
//     {
//         // Vector3 desiredPos = target.position + offset;
//         // Vector3 smoothedPos = Vector3.Lerp(transform.position, desiredPos, smooth*Time.deltaTime);
//         // transform.position = smoothedPos;
//         
//         // transform.LookAt(target);
//     }
//
//
//     // Start is called before the first frame update
//     void Start()
//     {
//         
//     }
//
//     // Update is called once per frame
//     void Update()
//     {
//         
//     }
// }
